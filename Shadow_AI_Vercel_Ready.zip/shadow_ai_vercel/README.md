# Shadow AI Vercel deployment

This package contains the updated Shadow AI study app plus the serverless AI gateway required for real text + image question solving.

## Deploy
1. Upload/deploy this folder as a Vercel project.
2. In Vercel Project Settings → Environment Variables, add:
   - `OPENAI_API_KEY` = your OpenAI API key
   - Optional: `OPENAI_MODEL` = `gpt-5.6-luna`
3. Redeploy.
4. Open the app. Shadow AI already uses `/api/shadow-ai` by default.

Do NOT put the API key inside `index.html`.

The gateway accepts text and base64 image data URLs and forwards them to the OpenAI Responses API. Image inputs are supported by the Responses API.
